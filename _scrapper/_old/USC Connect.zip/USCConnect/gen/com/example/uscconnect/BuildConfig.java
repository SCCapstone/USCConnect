/** Automatically generated file. DO NOT MODIFY */
package com.example.uscconnect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}